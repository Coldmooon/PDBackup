# pandownload-fake-server
https://www.hostloc.com/thread-675311-1-1.html

**没有加速功能**

感谢 hostloc@xjxaixxy 大佬提供的思路与文件

感谢 [Womsxd/pandownload.com_Pages_Backup](https://github.com/Womsxd/pandownload.com_Pages_Backup) 的脚本文件
# 使用方法
~~1. 下载带脚本缓存的Pandownload~~
 
服务端添加了更多文件，已无需缓存，使用原客户端即可

1. hosts 添加
```
64.52.84.68 pandownload.com
```
~~由于请求内有算法生成的bdc token，此方法的有效时间未知，且用且珍惜~~

目前看来bdc token和启动并无太大联系，理论上此方法将一直可用
# 想说的话
**F\*\*k Baidu**
